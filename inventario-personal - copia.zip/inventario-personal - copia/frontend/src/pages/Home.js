function Home() {
  return (
    <div className="container">
      <h1>Bienvenido al Inventario Personal</h1>
      <p><a href="/login">Inicia sesión</a> o <a href="/dashboard">ve al panel</a>.</p>
    </div>
  );
}

export default Home;